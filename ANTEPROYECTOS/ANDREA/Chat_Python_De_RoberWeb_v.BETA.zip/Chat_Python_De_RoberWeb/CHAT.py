import socket, os, threading, time

"""
Autor: Roberweb
Web: http://www.roberweb.wordpress.com
Se puede modificar el codigo
"""

threadBreak = False



def escuchar(sc):
    while True:
          recibido = sc.recv(1024)
          if recibido == "quit":
              sc.send("quit")
              break      
          print "\nRecibido: ", recibido, "\n"
          #sc.send(recibido)

def escribir(sc, stop_event):
    while (not stop_event.is_set()):
          mensaje = raw_input("> ")
          if (not stop_event.is_set()):
              sc.send(mensaje)
          if mensaje == "quit":
              break
          stop_event.wait(1)

def servidor():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    s.bind(("localhost", 9995))
    s.listen(1)

    sc, addr = s.accept()
    
    tarea2_stop = threading.Event()
    tarea1 = threading.Thread(target = escuchar, args=(sc,))
    tarea2 = threading.Thread(target = escribir, args=(sc, tarea2_stop))
    tarea1.start()
    tarea2.start()
    tarea1.join()
    tarea2_stop.set()
     
    initing()

def cliente():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    s.connect(("localhost", 9995))

    tarea2_stop = threading.Event()
    tarea1 = threading.Thread(target = escuchar, args=(s,))
    tarea2 = threading.Thread(target = escribir, args=(s, tarea2_stop))
    tarea1.start()
    tarea2.start()
    tarea1.join()
    tarea2_stop.set()
 
    initing()
    
def initing():
    print "    CHAT:\n1. Crear una sala\n2. Unirse a una sala\n3. Salir\nEscriba quit para salir, tambien funcionara en el chat."
    c=raw_input(">> ")
    if c == "1":
        servidor()
    if c == "2":
        cliente()
    if c == "3":
        try:
            print "Adios"
            try:
                sc.close()
                s.close()
                exit()
                try:
                    s.close()
                    exit()
                except:
                    exit()                
            except:
                exit()
        except:
            exit()
            
initing()
